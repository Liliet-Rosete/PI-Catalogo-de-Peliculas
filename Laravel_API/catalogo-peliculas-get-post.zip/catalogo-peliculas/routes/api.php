<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('/movies', function () {
    return \App\Models\Movie::all();
});
Route::get('/movies/{id}', function ($id) {
    return \App\Models\Movie::find($id);
});
Route::post('/movies', function (Request $request) {
    return \App\Models\Movie::create([
        'title' => $request->title,
        'synopsis' => $request->synopsis,
        'year' => $request->year,
        'cover' => $request->cover,
    ]);
});